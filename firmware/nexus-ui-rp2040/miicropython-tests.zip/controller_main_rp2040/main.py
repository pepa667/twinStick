from machine import Pin, UART
import utime

uart = UART(0,115200)

pins = {
"UP":Pin(2,Pin.IN,Pin.PULL_UP),
"DOWN":Pin(3,Pin.IN,Pin.PULL_UP),
"LEFT":Pin(4,Pin.IN,Pin.PULL_UP),
"RIGHT":Pin(5,Pin.IN,Pin.PULL_UP),

"A":Pin(10,Pin.IN,Pin.PULL_UP),
"B":Pin(11,Pin.IN,Pin.PULL_UP),
"X":Pin(12,Pin.IN,Pin.PULL_UP),
"Y":Pin(13,Pin.IN,Pin.PULL_UP),
"L":Pin(14,Pin.IN,Pin.PULL_UP),
"R":Pin(15,Pin.IN,Pin.PULL_UP),
"START":Pin(16,Pin.IN,Pin.PULL_UP),
"SELECT":Pin(17,Pin.IN,Pin.PULL_UP),

"BT":Pin(18,Pin.IN,Pin.PULL_UP),
"PROFILE":Pin(19,Pin.IN,Pin.PULL_UP)
}

def socd(up,down,left,right):

    if up and down:
        up=0
        down=0

    if left and right:
        left=0
        right=0

    return up,down,left,right


while True:

    up = not pins["UP"].value()
    down = not pins["DOWN"].value()
    left = not pins["LEFT"].value()
    right = not pins["RIGHT"].value()

    up,down,left,right = socd(up,down,left,right)

    state = 0

    if up: state |= 1<<0
    if down: state |= 1<<1
    if left: state |= 1<<2
    if right: state |= 1<<3

    if not pins["A"].value(): state |= 1<<4
    if not pins["B"].value(): state |= 1<<5
    if not pins["X"].value(): state |= 1<<6
    if not pins["Y"].value(): state |= 1<<7
    if not pins["L"].value(): state |= 1<<8
    if not pins["R"].value(): state |= 1<<9
    if not pins["START"].value(): state |= 1<<10
    if not pins["SELECT"].value(): state |= 1<<11

    if not pins["BT"].value(): state |= 1<<12
    if not pins["PROFILE"].value(): state |= 1<<13

    lo = state & 0xFF
    hi = (state >> 8) & 0xFF

    checksum = lo ^ hi


    uart.write(bytes([0xAA, lo, hi, lo ^ hi]))
    print(bytes([0xAA,lo,hi,checksum]))
    print(state)
    
    utime.sleep_ms(1)