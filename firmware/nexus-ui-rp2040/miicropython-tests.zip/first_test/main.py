'''
HELL YEAH! Nexus UI is alive!
First run: Testing GPIO reads and UART comms.
'''

from machine import Pin, UART
import time

uart = UART(0, baudrate=115200, tx=Pin(0), rx=Pin(1))

UP = Pin(2, Pin.IN, Pin.PULL_UP)
DOWN = Pin(3, Pin.IN, Pin.PULL_UP)
LEFT = Pin(4, Pin.IN, Pin.PULL_UP)
RIGHT = Pin(5, Pin.IN, Pin.PULL_UP)

A = Pin(6, Pin.IN, Pin.PULL_UP)
B = Pin(7, Pin.IN, Pin.PULL_UP)
X = Pin(8, Pin.IN, Pin.PULL_UP)
Y = Pin(9, Pin.IN, Pin.PULL_UP)

L = Pin(10, Pin.IN, Pin.PULL_UP)
R = Pin(11, Pin.IN, Pin.PULL_UP)

START = Pin(12, Pin.IN, Pin.PULL_UP)
SELECT = Pin(13, Pin.IN, Pin.PULL_UP)

BT = Pin(18, Pin.IN, Pin.PULL_UP)
PROFILE = Pin(19, Pin.IN, Pin.PULL_UP)

last_state = -1


def read_buttons():

    b = 0

    if not UP.value(): b |= 1<<0
    if not DOWN.value(): b |= 1<<1
    if not LEFT.value(): b |= 1<<2
    if not RIGHT.value(): b |= 1<<3

    if not A.value(): b |= 1<<4
    if not B.value(): b |= 1<<5
    if not X.value(): b |= 1<<6
    if not Y.value(): b |= 1<<7

    if not L.value(): b |= 1<<8
    if not R.value(): b |= 1<<9

    if not START.value(): b |= 1<<10
    if not SELECT.value(): b |= 1<<11

    if not BT.value(): b |= 1<<12
    if not PROFILE.value(): b |= 1<<13

    return b


def send_state(state):

    lo = state & 0xFF
    hi = (state >> 8) & 0xFF
    checksum = (lo + hi) & 0xFF

    uart.write(bytes([
        0xAA,
        lo,
        hi,
        checksum
    ]))


while True:

    state = read_buttons()

    if state != last_state:
        send_state(state)
        last_state = state

    time.sleep_ms(1)