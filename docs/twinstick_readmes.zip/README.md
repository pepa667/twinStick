# TwinStick

TwinStick is an open-source **dual-player arcade controller platform** supporting **USB and Bluetooth connectivity** with multiple HID profiles.

The system uses a distributed architecture:

- **RP2040** as the main controller and UI
- **Two ESP32 modules**, one per player
- Shared UART protocol for communication

The goal of the project is to create a **universal arcade controller platform** compatible with multiple systems such as PC and Nintendo Switch.

---

# Architecture

RP2040 (NexusUI)
   │
   ├── UART → ESP32 (HydraCore P1)
   └── UART → ESP32 (HydraCore P2)

Each ESP32 represents an independent wireless controller.

---

# Main Modules

## NexusUI (RP2040)

Responsibilities:

- Scan arcade buttons and joysticks
- Manage LCD configuration interface
- Control system profiles
- Send controller state to ESP32 modules
- Optional USB HID mode

Features:

- Shift-register input expansion
- Menu system on LCD display
- ArcadeLink UART protocol

---

## HydraCore (ESP32)

HydraCore is responsible for:

- Bluetooth connectivity
- HID profile emulation
- Pairing and wireless communication

HydraCore uses:

**HOJA-LIB-ESP32**

Supported profiles:

- XInput
- DInput
- Nintendo Switch Pro Controller

---

# Communication

The RP2040 broadcasts controller states using **ArcadeLink protocol** via UART.

Packet structure:

HEADER | PLAYER_ID | TYPE | DATA | CHECKSUM

Both ESP32 receive the stream but process only their PLAYER_ID.

---

# Modes

## USB

Arcade → RP2040 → USB HID → Host

## Bluetooth

Arcade → RP2040 → UART → ESP32 → Bluetooth → Host

---

# Repository Structure

firmware/
  hydra-core-esp32/
  nexus-ui-rp2040/

protocol/
hardware/
docs/

---

# License

MIT License
